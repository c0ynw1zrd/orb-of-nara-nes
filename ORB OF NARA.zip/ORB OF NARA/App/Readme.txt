Copy this with your release.
Source code for emulator NESTEK
https://github.com/kilgariff/nestek

